class CreateGossips < ActiveRecord::Migration[5.1]
  def change
    create_table :gossips do |t|
      t.string :anonymous_author
      t.string :contect
      t.string :title
      t.text :text

      t.timestamps
    end
  end
end
