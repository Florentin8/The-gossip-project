class GossipsController < ApplicationController
  def show
    @gossips = Gossips.find(params[:id])
  end

  def new
  end

  def create
    @gossips = Gossips.new(params[:gossips])

    @gossips.save
    redirect_to @gossips
  end

  private
  def gossips_params
    params.require(:gossips).permit(:anonymous_author, :contect)
  end
end
